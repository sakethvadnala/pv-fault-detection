import { serve } from "https://deno.land/std/http/server.ts";

serve(async (req) => {
  try {
    const body = await req.json();
    const dataset = body.data;

    if (!dataset || dataset.length === 0) {
      return new Response(JSON.stringify({ error: "No data" }), { status: 400 });
    }

    // use last row
    const row = dataset[dataset.length - 1];

    // call ML backend
    const mlResponse = await fetch("http://host.docker.internal:8000/predict", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({
    Voltage: Number(row.Voltage),
    Current: Number(row.Current),
    Power: Number(row.Power),
    Irradiance: Number(row.Irradiance),
    Temperature: Number(row.Temperature)
  })
});

    const ml = await mlResponse.json();

    // ML now returns full distribution
    // { fault, confidence, probabilities }

    const probabilities = ml.probabilities;

    const predictions = Object.entries(probabilities).map(
      ([faultType, probability]) => ({
        faultType,
        probability
      })
    );

    const topPrediction = {
      faultType: ml.fault,
      probability: ml.confidence
    };

    let severity: "Low" | "Medium" | "High" | "Critical" = "Low";
    if (ml.confidence > 0.9) severity = "High";
    else if (ml.confidence > 0.75) severity = "Medium";

    return new Response(
      JSON.stringify({
        predictions,
        topPrediction,
        severity,
        timestamp: new Date().toISOString()
      }),
      { headers: { "Content-Type": "application/json" } }
    );

  } catch (err) {
    return new Response(
      JSON.stringify({ error: String(err) }),
      { status: 500 }
    );
  }
});